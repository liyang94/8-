var a = 'js0';
var js1 = require('./js1.js')
var js2 = require('./js2.js')